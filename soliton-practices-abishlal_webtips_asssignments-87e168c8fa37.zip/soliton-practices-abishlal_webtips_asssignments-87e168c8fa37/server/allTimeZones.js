const { allTimeZones } = require("./timeZone.js");

process.send(allTimeZones());